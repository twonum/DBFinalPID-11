﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class Page : Form
    {
        public Page()
        {
            InitializeComponent();

            SetPictureBox(pictureBox1, "dashboard.png", 250, 150);
            SetPictureBox(pictureBox2, "db1.png", 110, 120);
            SetPictureBox(pictureBox3, "db2.png", 110, 120);
            SetPictureBox(pictureBox4, "maximize.png", 27, 23);
            SetPictureBox(pictureBox5, "close.png", 20, 19);
        }

        private void SetPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            panel2.Width += 6;

            if  (panel2.Width >= 750)
            {
                timer1.Stop();

                LoginForm l1 = new LoginForm ();
                l1.Show();
                this.Hide();
            }
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
           
        }

        private void Page_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void pictureBox5_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox4_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
    }
}
