﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class ClerkMenu : Form
    {
        public ClerkMenu()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "clerk-min.png", 110, 120);
            //SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void ClerkMenu_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ClerkMenu cm = new ClerkMenu();
            this.Hide();
            cm.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ManageCourses mc = new ManageCourses();
            this.Hide();
            mc.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AssignAdvisor ad = new AssignAdvisor();
            this.Hide();
            ad.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ManageStudents ms = new ManageStudents();
            this.Hide();
            ms.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            StuAssAdv adv = new StuAssAdv();
            this.Hide();
            adv.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddAdvisor aa = new AddAdvisor();
            aa.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddInstructor aa = new AddInstructor();
            aa.Show();
            this.Hide();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            ManageStudents manageStudents = new ManageStudents();
            this.Hide();
            manageStudents.Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            ManageCourses manageCourses = new ManageCourses();
            this.Hide();
            manageCourses.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }
    }
}
