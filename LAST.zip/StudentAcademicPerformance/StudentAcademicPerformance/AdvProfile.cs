﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AdvProfile : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";
        private const string DiscussionImagePath = "discussion-min.png";
        private const string ArrowImagePath = "arrow-min.png";
        private const string MaximizeImagePath = "maximize.png";
        private const string CloseImagePath = "close.png";

        public AdvProfile()
        {
            InitializeComponent();
            SetupPictureBoxes();
            LoadAdvisorDetails();
        }

        private void SetupPictureBoxes()
        {
            SetupPictureBox(pictureBox1, DiscussionImagePath, 110, 120);
            SetupPictureBox(pictureBox2, ArrowImagePath, 30, 40);
            SetupPictureBox(pictureBox3, MaximizeImagePath, 27, 25);
            SetupPictureBox(pictureBox4, CloseImagePath, 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Width = width;
            pictureBox.Height = height;
        }

        private void LoadAdvisorDetails()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("SELECT * FROM AdvisorDetailsView", connection))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading advisor details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void LoadAdvisorDetails(int advisorId)
        {
            dataGridView1.DataSource = null;

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("GetAdvisorDetails", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@AdvisorId", advisorId);

                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading advisor details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        }
        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1.Text, out int advisorId))
            {
                MessageBox.Show("Please enter a valid advisor ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            LoadAdvisorDetails(advisorId);
        }

        private void btnForgotID_Click(object sender, EventArgs e)
        {
            lblAdvName.Visible = true;
            txtAdvName.Visible = true;
            dataGridView2.Visible = true;
            LoadAdvisors();
        }
        private void LoadAdvisors()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("GetAdvisors", connection))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView2.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading advisors: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void LoadAdvisorSuggestions(string namePattern)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("GetAdvisorSuggestions", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@NamePattern", namePattern);
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView2.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading advisor suggestions: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void txtAdvID_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                if (int.TryParse(textBox1.Text, out int advisorId))
                {
                    LoadStudentsByAdvisor(advisorId);
                }
                else
                {
                    MessageBox.Show("Please enter a valid Advisor ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                LoadAdvisors();
            }
        }

        private void LoadStudentsByAdvisor(int advisorId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("GetStudentsByAdvisorId", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@AdvisorId", advisorId);
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading students: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("Please enter a valid Advisor ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (int.TryParse(textBox1.Text, out int advisorId))
                    {
                        LoadAdvisorDetails(advisorId);
                    }
                    else
                    {
                        MessageBox.Show("Please enter a valid Advisor ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        LoadAdvisorDetails();
                    }
                }
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                LoadAdvisorDetails();
            }
            else
            {
                if (int.TryParse(textBox1.Text, out int advisorId))
                {
                    LoadAdvisorDetails(advisorId);
                }
                else
                {
                    MessageBox.Show("Please enter a valid Advisor ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    LoadAdvisorDetails();// Refresh grid if the input is not a valid integer
                }
            }
        }

        private void txtAdvName_TextChanged_1(object sender, EventArgs e)
        {
            string advisorNamePattern = txtAdvName.Text.Trim();
            if (string.IsNullOrEmpty(advisorNamePattern))
            {
                LoadAdvisors();
            }
            else
            {
                LoadAdvisorSuggestions(advisorNamePattern);
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox4_Click_1(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click_1(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            AdvMenu1 am = new AdvMenu1();
            this.Hide();
            am.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdvAppointment adv = new AdvAppointment();
            this.Hide(); adv.Show();
        }
    }
}
