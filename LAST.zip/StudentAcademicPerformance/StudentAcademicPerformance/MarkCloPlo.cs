﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class MarkCloPlo : Form
    {
        private const string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Update with your SQL Server connection string

        public MarkCloPlo()
        {
            InitializeComponent();
            SetupPictureBox(pictureBox1, "teacher1-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox2.Text.Trim();
            string cloAssessmentId = textBox1.Text.Trim();

            if (!decimal.TryParse(textBox5.Text.Trim(), out decimal score))
            {
                MessageBox.Show("Please enter a valid score.");
                return;
            }
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("InsertStudentCLOAssessmentOutcome", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                        command.Parameters.AddWithValue("@CLO_AssessmentId", cloAssessmentId);
                        command.Parameters.AddWithValue("@Score", score);

                        string result = command.ExecuteScalar()?.ToString();
                        MessageBox.Show(result); // Show success message
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();
        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox2.Text.Trim();
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("LoadStudentCLOAssessmentOutcome", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            DataTable dataTable = new DataTable();
                            dataTable.Load(reader);
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void MarkCloPlo_Load(object sender, EventArgs e)
        {
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SubmitGrades sg = new SubmitGrades();
            this.Hide();
            sg.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            InsMarkAttendance ism = new InsMarkAttendance();
            this.Hide();
            ism.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MarkCloPlo mcp = new MarkCloPlo();
            this.Hide();
            mcp.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            InsMenu1 im = new InsMenu1();
            this.Hide();
            im.Show();
        }
    }
}
