﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class StuAssAdv : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public StuAssAdv()
        {
            InitializeComponent();
            SetupPictureBoxes();
            LoadAssignedStudentsAsync();
        }

        private void SetupPictureBoxes() => new PictureBox[] { pictureBox1, pictureBox2, pictureBox4, pictureBox3 }
            .ToList().ForEach(pictureBox => SetupPictureBox(pictureBox));

        private void SetupPictureBox(PictureBox pictureBox)
        {
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(110, 120); // Default size
        }

        private async Task LoadAssignedStudentsAsync()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("SELECT * FROM AssignedStudentsView", connection))
                {
                    await connection.OpenAsync();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(await command.ExecuteReaderAsync());
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (SqlException ex)
            {
                ShowErrorMessage($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading assigned students: {ex.Message}");
            }
        }
        private void ShowErrorMessage(string message) => MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();
        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void StuAssAdv_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            ManageStudents ms = new ManageStudents();
            this.Hide();
            ms.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ManageCourses mc = new ManageCourses();
            this.Hide();
            mc.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AssignAdvisor ad = new AssignAdvisor();
            this.Hide();
            ad.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            StuAssAdv adv = new StuAssAdv();
            this.Hide();
            adv.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ClerkMenu cm = new ClerkMenu();
            this.Hide();
            cm.Show(); 
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            ManageStudents manageStudents = new ManageStudents();
            this.Hide();
            manageStudents.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            ManageCourses manageCourses = new ManageCourses();
            this.Hide();
            manageCourses.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddAdvisor aa = new AddAdvisor();
            aa.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddInstructor aa = new AddInstructor();
            aa.Show();
            this.Hide();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }
    }
}
