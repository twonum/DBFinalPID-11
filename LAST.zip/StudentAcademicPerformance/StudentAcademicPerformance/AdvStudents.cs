﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AdvStudents : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public AdvStudents()
        {
            InitializeComponent();
            SetupPictureBoxes();
            LoadAdvisors();
        }

        private void SetupPictureBoxes()
        {
            SetupPictureBox(pictureBox1, "discussion-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void AdvStudents_Load(object sender, EventArgs e)
        {

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void btnViewData_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtAdvID.Text, out int advisorId))
            {
                LoadStudentsByAdvisor(advisorId);
            }
            else
            {
                ShowErrorMessage("Please enter a valid Advisor ID.");
            }
        }
        private void LoadAdvisors()
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var adapter = new SqlDataAdapter("GetAdvisors", connection))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView2.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading advisors: {ex.Message}");
            }
        }
        private void txtAdvID_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtAdvID.Text) && int.TryParse(txtAdvID.Text, out int advisorId))
            {
                LoadStudentsByAdvisor(advisorId);
            }
            else
            {
                LoadAdvisors();
            }
        }
        private void ShowAdvisorDetails()
        {
            label2.Visible = true;
            txtAdvID.Visible = true;
            dataGridView2.Visible = true;
            LoadAdvisors();
        }
        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        private void LoadStudentsByAdvisor(int advisorId)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("GetStudentsByAdvisorId", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@AdvisorId", advisorId);
                    connection.Open();
                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading students: {ex.Message}");
            }
        }
        private void btnForgotId_Click(object sender, EventArgs e)
        {
            ShowAdvisorDetails();
        }

        private void txtAdvName_TextChanged(object sender, EventArgs e)
        {
            string advisorNamePattern = txtAdvName.Text.Trim();
            if (string.IsNullOrEmpty(advisorNamePattern))
            {
                LoadAdvisors();
            }
            else
            {
                LoadAdvisorSuggestions(advisorNamePattern);
            }
        }
        private void LoadAdvisorSuggestions(string namePattern)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("GetAdvisorSuggestions", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@NamePattern", namePattern);
                    connection.Open();
                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView2.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading advisor suggestions: {ex.Message}");
            }
        }
        private void pictureBox4_Click_1(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click_1(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            AdvMenu1 am = new AdvMenu1();
            this.Hide();
            am.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdvAppointment adv = new AdvAppointment();
            this.Hide(); adv.Show();
        }
    }
}
