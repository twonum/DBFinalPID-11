﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AdvAppointment : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";
        public AdvAppointment()
        {
            InitializeComponent();
            SetupPictureBoxes();
        }
        private void SetupPictureBoxes()
        {
            SetupPictureBox(pictureBox1, "discussion-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Width = width;
            pictureBox.Height = height;
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void AdvAppointment_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click_1(object sender, EventArgs e)=>this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        private void pictureBox4_Click_1(object sender, EventArgs e)=>Application.Exit();

        private async void button1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox1.Text, out int advisorId))
            {
                ShowErrorMessage("Please enter a valid advisor ID.");
                return;
            }

            await LoadAppointmentsAsync(advisorId);
        }
        private async Task LoadAppointmentsAsync(int advisorId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("GetAppointmentsByAdvisorId", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@AdvisorId", advisorId);

                        await connection.OpenAsync();

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            await Task.Run(() => adapter.Fill(dataTable));
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                ShowErrorMessage($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error: {ex.Message}");
            }
        }
        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void btnForgotID_Click(object sender, EventArgs e)
        {
            lblAdvName.Visible = true;
            txtAdvName.Visible = true;
            dataGridView2.Visible = true;
            LoadAdvisors();
        }
        private async void LoadAdvisors()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("GetAdvisors", connection))
                    {
                        await connection.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            await Task.Run(() => adapter.Fill(dataTable));
                            dataGridView2.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                ShowErrorMessage($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error: {ex.Message}");
            }
        }

        private void txtAdvName_TextChanged(object sender, EventArgs e)
        {
            string advisorNamePattern = txtAdvName.Text.Trim();
            if (string.IsNullOrEmpty(advisorNamePattern))
            {
                LoadAdvisors();
            }
            else
            {
                LoadAdvisorSuggestions(advisorNamePattern);
            }
        }
        private async void LoadAdvisorSuggestions(string namePattern)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("GetAdvisorSuggestions", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@NamePattern", namePattern);
                        await connection.OpenAsync();
                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            await Task.Run(() => adapter.Fill(dataTable));
                            dataGridView2.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                ShowErrorMessage($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error: {ex.Message}");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                LoadAdvisors();
            }
            else
            {
                if (int.TryParse(textBox1.Text, out int advisorId))
                {
                    GetAppointmentsByAdvisorId(advisorId);
                }
                else
                {
                    MessageBox.Show("Please enter a valid Advisor ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    // Remove the call to LoadAdvisors() here
                }
            }
        }
        private async void GetAppointmentsByAdvisorId(int advisorId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    using (SqlCommand command = new SqlCommand("GetAppointmentsByAdvisorId", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@AdvisorId", advisorId);

                        await connection.OpenAsync();

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dataTable = new DataTable();
                            await Task.Run(() => adapter.Fill(dataTable));
                            dataGridView1.DataSource = dataTable;
                        }
                    }
                }
            }
            catch (SqlException ex)
            {
                ShowErrorMessage($"SQL Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error: {ex.Message}");
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            AdvMenu1 am = new AdvMenu1();
            this.Hide();
            am.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdvAppointment adv = new AdvAppointment();
            this.Hide(); adv.Show();
        }
    }
}
