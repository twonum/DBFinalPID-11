﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AssignAdvisor : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public AssignAdvisor()
        {
            InitializeComponent();
            InitializeUI();
            LoadData();
            //WireEvents();
        }
        private void InitializeUI()
        {
            LoadImages();
            LoadComboBoxData();
        }

        private void LoadImages()
        {
            pictureBox1.Image = LoadImage("clerk-min.png", new Size(110, 120));
            pictureBox2.Image = LoadImage("arrow-min.png", new Size(30, 40));
            pictureBox3.Image = LoadImage("maximize.png", new Size(27, 25));
            pictureBox4.Image = LoadImage("close.png", new Size(18, 19));
        }
        private void LoadData()
        {
            LoadDataGridView(dataGridView1, "SELECT * FROM StudentAdvisorView");
            LoadDataGridView(dataGridView2, "SELECT * FROM AdvisorDepartmentView");
        }
        private Image LoadImage(string fileName, Size size)
        {
            return Image.FromFile(fileName);
        }

        private void LoadComboBoxData()
        {
            LoadComboBoxItems(comboBox1, "SELECT DISTINCT Registration_Number FROM Student");
            LoadComboBoxItems(comboBox2, "SELECT DISTINCT AdvisorId FROM Advisor");
        }
        private void LoadComboBoxItems(ComboBox comboBox, string query)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand(query, connection))
                {
                    connection.Open();
                    var reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        comboBox.Items.Add(reader[0].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading data into {comboBox.Name}: {ex.Message}");
            }
        }
        //private void WireEvents()
        //{
        //    dataGridView1.CellClick += dataGridView1_CellClick;
        //}
        private void LoadDataGridView(DataGridView dataGridView, string query)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var adapter = new SqlDataAdapter(query, connection))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading data into {dataGridView.Name}: {ex.Message}");
            }
        }
        private void panel6_Paint(object sender, PaintEventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadData();
            ShowInfoMessage("Grid refreshed successfully.");
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            string advisorIdText = textBox2.Text.Trim();
            if (string.IsNullOrWhiteSpace(advisorIdText))
            {
                LoadData(); // Refresh the grids if the text box is empty
            }
            else if (int.TryParse(advisorIdText, out int advisorId))
            {
                FetchAppointmentsByAdvisorId(advisorId);
            }
            else
            {
                // Handle invalid input or clear the corresponding DataGridView
                dataGridView2.DataSource = null;
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            string registrationNumber = textBox1.Text.Trim();
            if (string.IsNullOrWhiteSpace(registrationNumber))
            {
                LoadData(); // Refresh the grids if the text box is empty
            }
            else
            {
                FetchAppointmentsByStudentRegistrationNumber(registrationNumber);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            FetchAppointments();
        }
        private void comboBox2_TextChanged(object sender, EventArgs e)
        {
            FetchAppointments();
        }
        private void FetchAppointments()
        {
            string registrationNumber = comboBox1.Text.Trim();
            string advisorIdText = comboBox2.Text.Trim();

            if (string.IsNullOrWhiteSpace(registrationNumber) && string.IsNullOrWhiteSpace(advisorIdText))
            {
                LoadData();
            }
            else if (!string.IsNullOrWhiteSpace(registrationNumber))
            {
                FetchAppointmentsByStudentRegistrationNumber(registrationNumber);
            }
            else if (int.TryParse(advisorIdText, out int advisorId))
            {
                FetchAppointmentsByAdvisorId(advisorId);
            }
            else
            {
                ShowErrorMessage("Please enter valid data.");
            }
        }
        private void FetchAppointmentsByStudentRegistrationNumber(string registrationNumber)
        {
            FetchAppointmentsByQuery($"SELECT * FROM StudentAdvisorView WHERE Registration_Number LIKE '%{registrationNumber}%'", dataGridView1);
        }

        private void FetchAppointmentsByAdvisorId(int advisorId)
        {
            FetchAppointmentsByQuery($"SELECT * FROM AdvisorDepartmentView WHERE AdvisorId = {advisorId}", dataGridView2);
        }
        private void FetchAppointmentsByQuery(string query, DataGridView dataGridView)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var adapter = new SqlDataAdapter(query, connection))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error fetching appointments: {ex.Message}");
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            AssignAdvisorToStudent();
        }
        private void AssignAdvisorToStudent()
        {
            string registrationNumber = comboBox1.Text.Trim();
            int advisorId;

            if (string.IsNullOrWhiteSpace(registrationNumber))
            {
                ShowErrorMessage("Please select a registration number.");
                return;
            }

            if (!int.TryParse(comboBox2.Text.Trim(), out advisorId))
            {
                ShowErrorMessage("Please enter a valid advisor ID.");
                return;
            }

            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("AssignAdvisorToStudent", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                    command.Parameters.AddWithValue("@AdvisorId", advisorId);

                    connection.Open();
                    command.ExecuteNonQuery();

                    ShowInfoMessage("Advisor assigned successfully.");

                    LoadData();
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error assigning advisor: {ex.Message}");
            }
        }
        private int GetAdvisorIdByNamesAndRegistrationNumber(string firstName, string lastName, string registrationNumber)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("GetAdvisorIdByNamesAndRegistrationNumber", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@FirstName", firstName);
                    command.Parameters.AddWithValue("@LastName", lastName);
                    command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);

                    connection.Open();
                    object result = command.ExecuteScalar();
                    return result != null && result != DBNull.Value ? Convert.ToInt32(result) : -1;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error retrieving advisor ID: {ex.Message}");
                return -1;
            }
        }
        private void ShowInfoMessage(string message)
        {
            MessageBox.Show(message, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox4_Click_1(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click_1(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ClerkMenu cm = new ClerkMenu();
            this.Hide();
            cm.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ManageStudents ms = new ManageStudents();
            this.Hide();
            ms.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AssignAdvisor adv = new AssignAdvisor();
            this.Hide();
            adv.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ManageCourses mc = new ManageCourses();
            this.Hide();
            mc.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            StuAssAdv adv = new StuAssAdv();
            adv.Show();
            this.Hide();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            ManageStudents manageStudents = new ManageStudents();
            this.Hide();
            manageStudents.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            ManageCourses manageCourses = new ManageCourses();
            this.Hide();
            manageCourses.Show();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AddAdvisor aa = new AddAdvisor();
            aa.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddInstructor aa = new AddInstructor();
            aa.Show();
            this.Hide();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }
    }
}
