﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class ManageCourses : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public ManageCourses()
        {
            InitializeComponent();
            InitializePictureBoxes();
            LoadDataIntoDataGridView();
        }

        private void InitializePictureBoxes()
        {
            pictureBox1.Image = pictureBox2.Image = Image.FromFile("clerk-min.png");
            pictureBox3.Image = Image.FromFile("maximize.png");
            pictureBox4.Image = Image.FromFile("close.png");

            foreach (var pictureBox in new[] { pictureBox1, pictureBox2, pictureBox3, pictureBox4 })
            {
                pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                pictureBox.Size = pictureBox == pictureBox1 ? new Size(110, 120) : new Size(27, 23);
            }
        }

        private void LoadDataIntoDataGridView()
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var adapter = new SqlDataAdapter("SELECT * FROM CoursesView", connection))
                {
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ShowErrorMessage(string message) => MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        private void button3_Click(object sender, EventArgs e)
        {
            LoadDataIntoDataGridView();
            ShowInfoMessage("Grid refreshed successfully.");
        }
        private void ShowInfoMessage(string message) => MessageBox.Show(message, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

        private void SetCommandParameters(SqlCommand command)
        {
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@CourseCode", textBox1.Text);
            command.Parameters.AddWithValue("@InstructorID", textBox5.Text);
            command.Parameters.AddWithValue("@CreditHours", textBox2.Text);
            command.Parameters.AddWithValue("@CourseTitle", textBox3.Text);
            command.Parameters.AddWithValue("@DepartmentName", textBox4.Text);
            command.Parameters.AddWithValue("@CourseDescription", textBox6.Text);
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }
        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Controls.OfType<TextBox>().Any(tb => string.IsNullOrWhiteSpace(tb.Text)))
            {
                ShowErrorMessage("All fields are required.");
                return;
            }

            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("AddCourse", connection))
                {
                    SetCommandParameters(command);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                LoadDataIntoDataGridView();
                ClearTextBoxes();
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error adding course: {ex.Message}");
            }
        }
        private void ClearTextBoxes()
        {
            foreach (var tb in Controls.OfType<TextBox>())
            {
                tb.Clear();
            }
        }
        private void UpdateCourse(int courseId)
        {
            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("UpdateCourse", connection))
                {
                    SetCommandParameters(command, courseId);
                    connection.Open();
                    command.ExecuteNonQuery();
                }

                LoadDataIntoDataGridView();
                ClearTextBoxes();
                ShowInfoMessage("Course updated successfully.");
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error updating course: {ex.Message}");
            }
        }

        private void SetCommandParameters(SqlCommand command, int courseId)
        {
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@CourseId", courseId);
            foreach (var parameter in new[]
            {
        ("@InstructorID", textBox5),
        ("@CreditHours", textBox2),
        ("@CourseTitle", textBox3),
        ("@DepartmentName", textBox4),
        ("@CourseDescription", textBox6)
    })
            {
                command.Parameters.AddWithValue(parameter.Item1, string.IsNullOrWhiteSpace(parameter.Item2.Text) ? DBNull.Value : (object)parameter.Item2.Text);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {

            if (Controls.OfType<TextBox>().All(tb => string.IsNullOrWhiteSpace(tb.Text)))
            {
                MessageBox.Show("No fields provided for update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                var courseId = GetCourseIdByCode(textBox1.Text);
                if (courseId == -1)
                {
                    MessageBox.Show("No course found with the provided Course Code.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                UpdateCourse(courseId);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating course: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                var courseCode = textBox1.Text.Trim();
                if (string.IsNullOrWhiteSpace(courseCode))
                {
                    ShowErrorMessage("Please provide a Course Code for deletion.");
                    return;
                }

                var courseId = GetCourseIdByCode(courseCode);
                if (courseId == -1)
                {
                    ShowErrorMessage("No course found with the provided Course Code.");
                    return;
                }

                DeleteCourse(courseId);
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error deleting course: {ex.Message}");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0 && dataGridView1.Columns[e.ColumnIndex].Name == "DELETE")
                {
                    var courseCode = dataGridView1.Rows[e.RowIndex].Cells["Course_Code"].Value.ToString();
                    var courseId = GetCourseIdByCode(courseCode);

                    if (courseId == -1)
                    {
                        ShowErrorMessage("No course found with the provided Course Code.");
                        return;
                    }

                    DeleteCourse(courseId);
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error deleting course: {ex.Message}");
            }
        }
        private int GetCourseIdByCode(string courseCode)
        {
            int courseId = -1; // Default value if course is not found

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("SELECT CourseId FROM Courses WHERE Course_Code = @CourseCode", connection))
                {
                    command.Parameters.AddWithValue("@CourseCode", courseCode);
                    connection.Open();
                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        courseId = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching CourseId: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            return courseId;
        }
        private void DeleteCourse(int courseId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("DeleteCourse", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CourseId", courseId);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        // Course deleted successfully from the database
                        LoadDataIntoDataGridView(); // Refresh data in the DataGridView
                        MessageBox.Show("Course deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        // No course found with the provided Course Id
                        MessageBox.Show("No course found with the provided Course Id.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting course: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void pictureBox4_Click_1(object sender, EventArgs e) => Application.Exit();

        private void dataGridView1_SelectionChanged_1(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                textBox1.Text = row.Cells["Course_Code"].Value.ToString();
                textBox2.Text = row.Cells["Credit_Hours"].Value.ToString();
                textBox3.Text = row.Cells["Course_Title"].Value.ToString();
                textBox4.Text = row.Cells["DepartmentName"].Value.ToString();
                textBox5.Text = row.Cells["InstructorID"].Value.ToString();
                textBox6.Text = row.Cells["Course_Description"].Value.ToString();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ClerkMenu cm = new ClerkMenu();
            this.Hide();
            cm.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ManageStudents ms = new ManageStudents();
            this.Hide();
            ms.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            ManageCourses mc = new ManageCourses();
            this.Hide();
            mc.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AssignAdvisor ad = new AssignAdvisor();
            this.Hide();
            ad.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            StuAssAdv adv = new StuAssAdv();
            this.Hide();
            adv.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            ManageStudents manageStudents = new ManageStudents();
            this.Hide();
            manageStudents.Show();
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            ManageCourses manageCourses = new ManageCourses();
            this.Hide();
            manageCourses.Show();
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            AddAdvisor aa = new AddAdvisor();
            aa.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddInstructor aa = new AddInstructor();
            aa.Show();
            this.Hide();
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
    }
}
