﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class ManageStudents : Form
    {
 private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public ManageStudents()
        {
            InitializeComponent();
            InitializePictureBoxes();
            LoadGrid1Data();
            dataGridView1.CellClick += dataGridView1_CellClick;
        }

        private void InitializePictureBoxes()
        {
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private async void LoadGrid1Data()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("SELECT * FROM StudentManagementView", connection))
                {
                    await connection.OpenAsync();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading data into grid1: {ex.Message}");
            }
        }

        private void ManageStudents_Load(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click_1(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private async void button1_Click(object sender, EventArgs e)
        {
            await AddStudentAsync();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateStudentAsync();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadGrid1Data(); // Refresh grid1
            ShowSuccessMessage("Grid refreshed successfully.");
        }

        private async void button4_Click(object sender, EventArgs e)
        {

            // Code for the DELETE button
            string regNumber = textBox1.Text;
            string username = textBox6.Text;
            string password = textBox7.Text;

            if (!string.IsNullOrEmpty(regNumber))
            {
                await DeleteStudentByRegistrationNumberAsync(regNumber);
            }
            else if (!string.IsNullOrEmpty(username) && !string.IsNullOrEmpty(password))
            {
                await DeleteStudentByUsernameAndPasswordAsync(username, password);
            }
            else
            {
                ShowErrorMessage("Please provide either registration number or username and password.");
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];

                // Load data into text boxes, combo box, and month selector
                textBox1.Text = selectedRow.Cells["Student_Reg_Number"].Value?.ToString();
                textBox3.Text = selectedRow.Cells["First_Name"].Value?.ToString();
                textBox4.Text = selectedRow.Cells["Last_Name"].Value?.ToString();
                textBox5.Text = selectedRow.Cells["Phone_Number"].Value?.ToString();
                textBox6.Text = selectedRow.Cells["System_Username"].Value?.ToString();
                comboBox1.Text = selectedRow.Cells["Gender"].Value?.ToString();
                textBox2.Text = selectedRow.Cells["Email"].Value?.ToString();
                textBox7.Text = selectedRow.Cells["Password"].Value?.ToString();
                monthCalendar1.SetDate(Convert.ToDateTime(selectedRow.Cells["Date_of_Birth"].Value));
            }
        }
        private async Task AddStudentAsync()
        {
            // Code for the ADD/INSERT button
            string regNumber = textBox1.Text;
            string firstName = textBox3.Text;
            string lastName = textBox4.Text;
            string phoneNumber = textBox5.Text;
            string username = textBox6.Text;
            string gender = comboBox1.Text;
            string email = textBox2.Text;
            string password = textBox7.Text;
            DateTime dob = monthCalendar1.SelectionStart;

            // Validate email
            if (!ValidateEmail(email))
            {
                ShowErrorMessage("Please enter a valid email address.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("InsertStudentWithUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Student_Reg_Number", regNumber);
                    command.Parameters.AddWithValue("@First_Name", firstName);
                    command.Parameters.AddWithValue("@Last_Name", lastName);
                    command.Parameters.AddWithValue("@Phone_Number", phoneNumber);
                    command.Parameters.AddWithValue("@System_Username", username);
                    command.Parameters.AddWithValue("@Gender", gender);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Date_of_Birth", dob);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();

                    await LoadGrid1DataAsync();
                    ShowSuccessMessage("Student added successfully.");
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error inserting student data: {ex.Message}");
            }
        }
        private async Task LoadGrid1DataAsync()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("SELECT * FROM StudentManagementView", connection))
                {
                    await connection.OpenAsync();
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error loading data into grid1: {ex.Message}");
            }
        }
        private async Task DeleteStudentByRegistrationNumberAsync(string registrationNumber)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("DeleteStudentByRegistrationNumber", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();

                    await LoadGrid1DataAsync();
                    ShowSuccessMessage("Student deleted successfully.");
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error deleting student data: {ex.Message}");
            }
        }

        private async Task DeleteStudentByUsernameAndPasswordAsync(string username, string password)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("DeleteStudentByUsernameAndPassword", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();

                    await LoadGrid1DataAsync();
                    ShowSuccessMessage("Student deleted successfully.");
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error deleting student data: {ex.Message}");
            }
        }
        private async Task UpdateStudentAsync()
        {
            // Retrieve data from the text boxes, combo box, and month selector
            string regNumber = textBox1.Text;
            string firstName = textBox3.Text;
            string lastName = textBox4.Text;
            string phoneNumber = textBox5.Text;
            string username = textBox6.Text;
            string gender = comboBox1.Text;
            string email = textBox2.Text;
            string password = textBox7.Text;
            DateTime dob = monthCalendar1.SelectionStart;

            // Validate email
            if (!ValidateEmail(email))
            {
                ShowErrorMessage("Please enter a valid email address.");
                return;
            }

            // Call the stored procedure to update student data
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("UpdateStudentWithUser", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Student_Reg_Number", regNumber);
                    command.Parameters.AddWithValue("@First_Name", firstName);
                    command.Parameters.AddWithValue("@Last_Name", lastName);
                    command.Parameters.AddWithValue("@Phone_Number", phoneNumber);
                    command.Parameters.AddWithValue("@System_Username", username);
                    command.Parameters.AddWithValue("@Gender", gender);
                    command.Parameters.AddWithValue("@Email", email);
                    command.Parameters.AddWithValue("@Password", password);
                    command.Parameters.AddWithValue("@Date_of_Birth", dob);

                    await connection.OpenAsync();
                    await command.ExecuteNonQueryAsync();

                    await LoadGrid1DataAsync();
                    ShowSuccessMessage("Student updated successfully.");
                }
            }
            catch (Exception ex)
            {
                ShowErrorMessage($"Error updating student data: {ex.Message}");
            }
        }
        private void ShowErrorMessage(string message)
        {
            MessageBox.Show(message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void ShowSuccessMessage(string message)
        {
            MessageBox.Show(message, "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private bool ValidateEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            ClerkMenu cm = new ClerkMenu();
            this.Hide();
            cm.Show();
        }
    }
}
