﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AddInstructor : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";
        public AddInstructor()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "clerk-min.png", 110, 120);
            SetupPictureBox(pictureBox5, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox4, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox3, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }
    

        private void button3_Click(object sender, EventArgs e)
        {
           
        }
        private void AddIns(string username, string password)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand("AddInstructor", connection);
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    command.ExecuteNonQuery();

                    MessageBox.Show("Instructor added successfully.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding instructor: " + ex.Message);
            }
        }
        private void LoadSystemUserTable()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM SystemUser", connection);
                    DataSet dataSet = new DataSet();
                    adapter.Fill(dataSet, "SystemUser");
                    dataGridView1.DataSource = dataSet.Tables["SystemUser"];
                    dataGridView1.Rows[dataGridView1.Rows.Count - 1].Selected = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading SystemUser table: " + ex.Message);
            }
        }
        private void AddInstructor_Load(object sender, EventArgs e)
        {
            LoadSystemUserTable();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadSystemUserTable();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {

            LoadSystemUserTable();
        }

        private void button16_Click(object sender, EventArgs e)
        {
            string username = textBox1.Text;
            string password = textBox2.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            AddIns(username, password);
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {
            LoadSystemUserTable();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)=>Application.Exit();

        private void pictureBox4_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            InsMenu1 im = new InsMenu1();
            this.Hide();
            im.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            ManageStudents manageStudents = new ManageStudents();
            this.Hide();
            manageStudents.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            ManageCourses manageCourses = new ManageCourses();
            this.Hide();
            manageCourses.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AddAdvisor aa = new AddAdvisor();
            aa.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddInstructor aa = new AddInstructor();
            aa.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            AssignAdvisor assignAdvisor = new AssignAdvisor();
            this.Hide();
            assignAdvisor.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }
    }
}
