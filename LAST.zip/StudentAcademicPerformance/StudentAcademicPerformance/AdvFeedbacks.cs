﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AdvFeedbacks : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public AdvFeedbacks()
        {
            InitializeComponent();
            SetupPictureBoxes();
            LoadFeedbacks();
        }

        private void SetupPictureBoxes()
        {
            SetupPictureBox(pictureBox1, "discussion-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "close.png", 18, 19);
            SetupPictureBox(pictureBox4, "maximize.png", 27, 25);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void LoadFeedbacks()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("SELECT * FROM FeedbackDetailsView", connection))
                {
                    connection.Open();
                    DataTable dataTable = new DataTable();
                    dataTable.Load(command.ExecuteReader());
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading feedbacks: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dataGridView1.Columns["Delete"].Index)
            {
                if (dataGridView1.Rows[e.RowIndex].DataBoundItem is DataRowView rowView)
                {
                    int feedbackId = Convert.ToInt32(rowView["Feedback_Id"]);
                    DeleteFeedback(feedbackId);
                }
            }
        }
        private void DeleteFeedback(int feedbackId)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(ConnectionString))
                using (SqlCommand command = new SqlCommand("DELETE FROM Feedback WHERE Feedback_Id = @FeedbackId", connection))
                {
                    command.Parameters.AddWithValue("@FeedbackId", feedbackId);
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Feedback deleted successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        LoadFeedbacks();
                    }
                    else
                    {
                        MessageBox.Show("Feedback not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting feedback: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            AdvMenu1 am = new AdvMenu1();
            this.Hide();
            am.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdvAppointment adv = new AdvAppointment();
            this.Hide(); adv.Show();
        }
    }
}
