﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace StudentAcademicPerformance
{
    public partial class StudentFeedback : Form
    {
        private const string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Update with your SQL Server connection string

        public StudentFeedback()
        {
            InitializeComponent();
            SetupPictureBox(pictureBox1, "graduated-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click_1(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button1_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox1.Text.Trim();
            string feedbackType = textBox2.Text.Trim();
            string feedbackText = textBox3.Text.Trim();

            if (string.IsNullOrEmpty(registrationNumber) || string.IsNullOrEmpty(feedbackType) || string.IsNullOrEmpty(feedbackText))
            {
                MessageBox.Show("Please enter valid registration number and feedback type along with feedback text.");
                return;
            }
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("SubmitFeedback", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                        command.Parameters.AddWithValue("@FeedbackType", feedbackType);
                        command.Parameters.AddWithValue("@FeedbackText", feedbackText);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Feedback submitted successfully.");

                        DataTable dt = new DataTable();
                        using (SqlCommand fetchCommand = new SqlCommand("SELECT TOP 1 * FROM Feedback ORDER BY FeedbackId DESC", connection))
                        {
                            SqlDataAdapter adapter = new SqlDataAdapter(fetchCommand);
                            adapter.Fill(dt);
                        }

                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudentFeedback sf = new StudentFeedback();
            this.Hide();
            sf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EnrollinCourses ec = new EnrollinCourses();
            this.Hide();
            ec.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StuMenu1 sm = new StuMenu1();
            this.Hide();
            sm.Show();
        }
    }
}
