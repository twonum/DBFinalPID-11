﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class InsMarkAttendance : Form
    {
        private const string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Update with your SQL Server connection string

        public InsMarkAttendance()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "teacher1-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox2.Text.Trim();
            string courseCode = textBox3.Text.Trim();
            int classesHeld;
            int classesAttended;

            if (string.IsNullOrEmpty(registrationNumber) || string.IsNullOrEmpty(courseCode))
            {
                MessageBox.Show("Please enter valid registration number and course code.");
                return;
            }

            if (!int.TryParse(textBox1.Text, out classesHeld) || !int.TryParse(textBox6.Text, out classesAttended))
            {
                MessageBox.Show("Please enter valid integer values for classes held and classes attended.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("MarkAttendance", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                        command.Parameters.AddWithValue("@CourseCode", courseCode);
                        command.Parameters.AddWithValue("@ClassesHeld", classesHeld);
                        command.Parameters.AddWithValue("@ClassesAttended", classesAttended);

                        command.ExecuteNonQuery();

                        MessageBox.Show("Attendance marked successfully.");

                        DataTable dt = new DataTable();
                        using (SqlCommand fetchCommand = new SqlCommand("SELECT TOP 1 * FROM Attendance ORDER BY AttendanceId DESC", connection))
                        {
                            SqlDataAdapter adapter = new SqlDataAdapter(fetchCommand);
                            adapter.Fill(dt);
                        }

                        dataGridView1.DataSource = dt;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while marking attendance: " + ex.Message);
            }
        }


        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SubmitGrades sg = new SubmitGrades();
            this.Hide();
            sg.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            InsMarkAttendance ism = new InsMarkAttendance();
            this.Hide();
            ism.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MarkCloPlo mcp = new MarkCloPlo();
            this.Hide();
            mcp.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            InsMenu1 im = new InsMenu1();
            this.Hide();
            im.Show();
        }
    }
}
