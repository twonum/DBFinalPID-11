﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class ScheduleAppointment : Form
    {
        private const string ConnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";

        public ScheduleAppointment()
        {
            InitializeComponent();
            SetupPictureBox(pictureBox1, "clerk-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void ScheduleAppointment_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button1_Click(object sender, EventArgs e)
        {
            ScheduleNewAppointment();
        }
        private void ScheduleNewAppointment()
        {
            int advisorId;
            string registrationNumber = textBox1.Text.Trim();
            string appointmentDate = textBox3.Text.Trim(); // Treat appointment date as string
            TimeSpan appointmentTime = TimeSpan.Parse(textBox3.Text.Trim());
            string appointmentStatus = comboBox1.SelectedItem?.ToString();

            if (!int.TryParse(textBox2.Text.Trim(), out advisorId))
            {
                MessageBox.Show("Please enter a valid advisor ID.");
                return;
            }

            try
            {
                using (var connection = new SqlConnection(ConnectionString))
                using (var command = new SqlCommand("InsertAppointment", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Set parameters
                    command.Parameters.AddWithValue("@AdvisorID", advisorId);
                    command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                    command.Parameters.AddWithValue("@AppointmentDate", appointmentDate);
                    command.Parameters.AddWithValue("@AppointmentTime", appointmentTime);
                    command.Parameters.AddWithValue("@AppointmentStatus", appointmentStatus);

                    connection.Open();
                    var result = command.ExecuteScalar();

                    if (result != null)
                    {
                        int appointmentID = Convert.ToInt32(result);
                        MessageBox.Show($"Appointment scheduled successfully with ID: {appointmentID}");
                    }
                    else
                    {
                        MessageBox.Show("Error scheduling appointment. Please check your input.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }
    }
}
