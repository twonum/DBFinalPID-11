﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class SubmitGrades : Form
    {
        private const string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Update with your SQL Server connection string

        public SubmitGrades()
        {
            InitializeComponent();
            SetupPictureBox(pictureBox1, "teacher1-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }
        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();
        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        private void button1_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox2.Text.Trim();
            string courseCode = comboBox2.Text.Trim();
            string grade = comboBox1.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(registrationNumber) || string.IsNullOrEmpty(courseCode) || string.IsNullOrEmpty(grade))
            {
                MessageBox.Show("Please fill out all fields.");
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("SubmitGrades", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                        command.Parameters.AddWithValue("@CourseCode", courseCode);
                        command.Parameters.AddWithValue("@Grade", grade);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                string result = reader["Result"].ToString();
                                MessageBox.Show(result);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SubmitGrades sg = new SubmitGrades();
            this.Hide();
            sg.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            InsMarkAttendance ism = new InsMarkAttendance();
            this.Hide();
            ism.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MarkCloPlo mcp = new MarkCloPlo();
            this.Hide();
            mcp.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            InsMenu1 im = new InsMenu1();
            this.Hide();
            im.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
