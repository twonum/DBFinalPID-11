﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class LoginForm : Form
    {
        private const string ggetconnectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Update with your SQL Server connection string

        public LoginForm()
        {
            InitializeComponent();
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            string username = textBox1.Text.Trim();
            string password = textBox2.Text.Trim(); // Assuming password needs trimming as well
            string role = comboBox1.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Please enter username, password, and role.");
                return;
            }

            string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Make sure you have a method to retrieve the connection string

            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    // Updated to retrieve SystemUserId as well
                    SqlCommand cmd = new SqlCommand("SELECT SystemUserId FROM SystemUser WHERE UserName=@username AND Password=@password AND Role=@role", con);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);
                    cmd.Parameters.AddWithValue("@role", role);

                    con.Open(); // Open the connection

                    object result = cmd.ExecuteScalar(); // Execute the command

                    if (result != null)
                    {
                        MessageBox.Show("Successful login: " + role);

                        switch (role)
                        {
                            case "Student":
                                StuMenu1 sm = new StuMenu1();
                                this.Hide();
                                sm.Show();
                                break;
                            case "Advisor":
                                AdvMenu1 am = new AdvMenu1();
                                this.Hide();
                                am.Show();
                                break;
                            case "Instructor":
                                InsMenu1 im = new InsMenu1();
                                this.Hide();
                                im.Show();
                                break;
                            case "Clerk":
                                ClerkMenu cm = new ClerkMenu();
                                this.Hide();
                                cm.Show();
                                break;
                            default:
                                MessageBox.Show("Invalid role specified");
                                return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Error Logging In!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        //private void NavigateToRoleForm(string role)
        //{
        //    string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";
     
        //    Form nextForm = null;

        //    try
        //    {
        //        using (SqlConnection con = new SqlConnection(connectionString))
        //        {
        //            con.Open(); // Open connection for this scope
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = con;

        //            switch (role)
        //            {
        //                case "Student":
        //                    nextForm = new StuMenu1();
        //                    break;
        //                case "Advisor":
        //                    nextForm = new AdvMenu1();
        //                    break;
        //                case "Instructor":
        //                    nextForm = new InsMenu1();
        //                    break;
        //                case "Clerk":
        //                    nextForm = new ClerkMenu();
        //                    break;
        //                default:
        //                    MessageBox.Show("Invalid role specified");
        //                    return;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MessageBox.Show("Error: " + ex.Message);
        //    }
        //}


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            textBox2.PasswordChar = checkBox1.Checked ? '\0' : '*';
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
    }
}
