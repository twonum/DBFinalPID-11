﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class AdvMenu1 : Form
    {
        public AdvMenu1()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "discussion-min.png", 110, 120);
            //SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void AdvMenu1_Load(object sender, EventArgs e)
        {

        }
        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox3_Click_1(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            //AdvProfile adp = new AdvProfile();
            //this.Hide();
            //adp.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            //AdvStudents adv = new AdvStudents();
            //this.Hide();
            //adv.Show();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            //AdvFeedbacks af = new AdvFeedbacks();
            //this.Hide();
            //af.Show();
        }

        private void label8_Click_1(object sender, EventArgs e)
        {
            AdvStudents adv = new AdvStudents();
            this.Hide();
            adv.Show();
        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            AdvProfile adp = new AdvProfile();
            this.Hide();
            adp.Show();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            AdvFeedbacks af = new AdvFeedbacks();
            this.Hide();
            af.Show();
        }
    }
}
