﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class EnrollinCourses : Form
    {
        private const string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True"; // Update with your SQL Server connection string

        public EnrollinCourses()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "graduated-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void button4_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox1.Text.Trim();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("GetCoursesNotEnrolled", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);

                        using (SqlDataAdapter adapter = new SqlDataAdapter(command))
                        {
                            DataTable dt = new DataTable();
                            adapter.Fill(dt);

                            dataGridView1.DataSource = dt;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string registrationNumber = textBox1.Text.Trim();
            string courseCode = textBox3.Text.Trim();

            if (string.IsNullOrEmpty(registrationNumber) || string.IsNullOrEmpty(courseCode))
            {
                MessageBox.Show("Please fill out both registration number and course code.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    using (SqlCommand command = new SqlCommand("EnrollinCourses", connection))
                    {
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@RegistrationNumber", registrationNumber);
                        command.Parameters.AddWithValue("@CourseCode", courseCode);

                        SqlDataReader reader = command.ExecuteReader();

                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                string resultMessage = reader["Result"].ToString();
                                MessageBox.Show(resultMessage, "Enrollment Status", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                        }
                        else
                        {
                            MessageBox.Show("Failed to enroll in course.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudentFeedback sf = new StudentFeedback();
            this.Hide();
            sf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EnrollinCourses ec = new EnrollinCourses();
            this.Hide();
            ec.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StuMenu1 sm = new StuMenu1();
            this.Hide();
            sm.Show();
        }
    }
}
