﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class StudentAcademicRecord : Form
    {
        public StudentAcademicRecord()
        {
            InitializeComponent();
            SetupPictureBox(pictureBox1, "graduated-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();
        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox1.Text))
            {
                MessageBox.Show("Please enter a registration number.");
                return;
            }

            string connectionString = @"Data Source=(local);Initial Catalog=StudentAcademicPerformance;Integrated Security=True";
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("ViewAcademicRecord", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    dataGridView1.DataSource = dt;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No records found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred: " + ex.Message);
                }
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StudentFeedback sf = new StudentFeedback();
            this.Hide();
            sf.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EnrollinCourses ec = new EnrollinCourses();
            this.Hide();
            ec.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            StuMenu1 sm = new StuMenu1();
            this.Hide();
            sm.Show();
        }
    }
}
