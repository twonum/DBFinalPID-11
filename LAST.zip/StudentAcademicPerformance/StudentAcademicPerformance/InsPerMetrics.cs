﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StudentAcademicPerformance
{
    public partial class InsPerMetrics : Form
    {
        public InsPerMetrics()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "teacher1-min.png", 110, 120);
            SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }
        private void InsPerMetrics_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            InsMenu1 im = new InsMenu1();
            this.Hide();
            im.Show();
        }
    }
}
