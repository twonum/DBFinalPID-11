﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace StudentAcademicPerformance
{
    public partial class InsMenu1 : Form
    {
        public InsMenu1()
        {
            InitializeComponent();

            SetupPictureBox(pictureBox1, "teacher1-min.png", 110, 120);
            //SetupPictureBox(pictureBox2, "arrow-min.png", 30, 40);
            SetupPictureBox(pictureBox3, "maximize.png", 27, 25);
            SetupPictureBox(pictureBox4, "close.png", 18, 19);
        }

        private void SetupPictureBox(PictureBox pictureBox, string imagePath, int width, int height)
        {
            pictureBox.Image = Image.FromFile(imagePath);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.Size = new Size(width, height);
        }
        private void label5_Click(object sender, EventArgs e)
        {
            InsProfile ip = new InsProfile();
            this.Hide();
            ip.Show();
        }


        private void panel5_Paint(object sender, PaintEventArgs e)
        {


        }

        private void label7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e) => Application.Exit();

        private void pictureBox3_Click(object sender, EventArgs e) => this.WindowState = this.WindowState == FormWindowState.Maximized ? FormWindowState.Normal : FormWindowState.Maximized;

        private void InsMenu1_Load(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            LoginForm lf = new LoginForm();
            this.Hide();
            lf.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SubmitGrades sg = new SubmitGrades();
            this.Hide();
            sg.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            InsMarkAttendance ism = new InsMarkAttendance();
            this.Hide();
            ism.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MarkCloPlo mcp = new MarkCloPlo();
            this.Hide(); 
            mcp.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            InsStuAcademic isa = new InsStuAcademic();
            this.Hide(); 
            isa.Show();
        }

        private void label7_Click_1(object sender, EventArgs e)
        {
            InsFeedbacks isf = new InsFeedbacks();
            this.Hide();
            isf.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            CourseRoster cr = new CourseRoster();
            this.Hide();
            cr.Show();
        }
    }
}
